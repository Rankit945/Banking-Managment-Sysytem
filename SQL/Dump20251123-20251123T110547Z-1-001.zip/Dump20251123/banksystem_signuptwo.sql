CREATE DATABASE  IF NOT EXISTS `banksystem` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `banksystem`;
-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: banksystem
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `signuptwo`
--

DROP TABLE IF EXISTS `signuptwo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `signuptwo` (
  `form_no` varchar(30) DEFAULT NULL,
  `religion` varchar(30) DEFAULT NULL,
  `category` varchar(30) DEFAULT NULL,
  `income` varchar(30) DEFAULT NULL,
  `education` varchar(30) DEFAULT NULL,
  `occuption` varchar(60) DEFAULT NULL,
  `pan` varchar(30) DEFAULT NULL,
  `aadhar` varchar(60) DEFAULT NULL,
  `seniorcitizen` varchar(30) DEFAULT NULL,
  `existing_account` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signuptwo`
--

LOCK TABLES `signuptwo` WRITE;
/*!40000 ALTER TABLE `signuptwo` DISABLE KEYS */;
INSERT INTO `signuptwo` VALUES (' 3096','Hindu','General','<1,50,000','Post-Graduate','Salaried','123456789','12345679','No','No'),(' 6223','Hindu','General','Null','Non-Graduate','Salaried','123456789','123456789','No','No'),(' 5183','Hindu','General','Null','Non-Graduate','Salaried','gyu','jyvgfu','No','No'),(' 3931','Hindu','General','Null','Non-Graduate','Salaried','ytftf','fyuyfuyf','No','No'),(' 1958','Hindu','General','Null','Non-Graduate','Salaried','bhuhi','givy','No','No'),(' 7936','Hindu','General','Null','Non-Graduate','Salaried','nbubh','ouhouhbo','No','No'),(' 2339','Hindu','General','Null','Non-Graduate','Salaried','ikuhgiu','giug','No','No'),(' 5653','Hindu','General','Null','Non-Graduate','Salaried','vyu','gig','No','No'),(' 954','Hindu','General','Null','Non-Graduate','Salaried','guigyiy','giygi','No','No'),(' 8742','Hindu','General','Null','Non-Graduate','Salaried','jhiugi','guoghou','No','No'),(' 3515','Hindu','General','Null','Non-Graduate','Salaried','bkbgu','kgubbk','No','No'),(' 4636','Hindu','General','Null','Non-Graduate','Salaried','bguyi','gigyu','No','No'),(' 2082','Hindu','General','Null','Non-Graduate','Salaried','ugiu','giiiiig','No','No'),(' 9270','Hindu','General','Null','Non-Graduate','Salaried','uih','iuyigi','No','No'),(' 5114','Hindu','General','Null','Non-Graduate','Salaried','e','e','No','No'),(' 1283','Hindu','General','Null','Non-Graduate','Salaried','d','igu',' ',' '),(' 1419','Hindu','General','Null','Non-Graduate','Salaried','ngle','gn','Yes','Yes'),(' 7707','Hindu','General','Null','Non-Graduate','Salaried','hm','mjm','No','No'),(' 1384','Hindu','General','Null','Non-Graduate','Salaried','4000','57689','Yes','Yes'),(' 5411','Hindu','General','Null','Non-Graduate','Salaried','676887','78','Yes','Yes'),(' 1799','Hindu','General','Null','Non-Graduate','Salaried','wejbuiwe','jkukwe','Yes','Yes'),(' 3551','Hindu','General','Null','Non-Graduate','Salaried','ghyt','jj','Yes','Yes'),(' 4227','Hindu','General','Null','Non-Graduate','Salaried','2234','577','Yes','Yes'),(' 3567','Hindu','General','Null','Non-Graduate','Salaried','hvhjvb','342545','Yes','Yes');
/*!40000 ALTER TABLE `signuptwo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-23 16:34:43

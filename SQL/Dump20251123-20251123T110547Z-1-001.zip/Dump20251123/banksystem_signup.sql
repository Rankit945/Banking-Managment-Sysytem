CREATE DATABASE  IF NOT EXISTS `banksystem` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `banksystem`;
-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: banksystem
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `signup`
--

DROP TABLE IF EXISTS `signup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `signup` (
  `form_no` varchar(30) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `father_name` varchar(30) DEFAULT NULL,
  `DOB` varchar(30) DEFAULT NULL,
  `gender` varchar(30) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `marital_status` varchar(30) DEFAULT NULL,
  `address` varchar(60) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `pincode` varchar(30) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signup`
--

LOCK TABLES `signup` WRITE;
/*!40000 ALTER TABLE `signup` DISABLE KEYS */;
INSERT INTO `signup` VALUES (' 1164','Ran','Pas','Oct 3, 2025','Male','rankitmittal07@gmail.com','Unmarried','asd','hisar','125113','haryana'),(' 3096','ABC','XYZ','Oct 24, 2025','Male','abc@gmail.com','Unmarried','123, abc colony','City','123678','Haryana'),(' 6223','a dj','bhb','Oct 15, 2025','Male','fsg','Married','','fsgd','huibg','guibg'),(' 5183','bhsgj','byugbu','Oct 15, 2025','Male','bhukhiku','Married','bkbguk','gubjg','guig','giuygiyg'),(' 3931','gjvfy','fuyu','Oct 14, 2025','Male','huiguig','Married','hiuhi','gihguig','guigiu','giugiu'),(' 1958','bgyiuy','ufvuyjf','bhuig','Male','giuiu','Married','khbug','giugb','giig','giyg'),(' 7936','gufyfu','fuyfuf','Oct 8, 2025','Male','bjkkbk','null','huguigiugig','giig','igig','igigi'),(' 2339','nhukh','hikgbik','nhbkuh','Male','hubuolhb','Married','houhbuo','uhgo','hhguoh','ugo'),(' 5653','bhujbki','gikugbi','huouhbik','Male','bubgik','Married','houh','gouh','giu','giugi'),(' 954','bkuiu','guig','huoh','Male','houou','Married','ihoih','hooi','hgoh','hooho'),(' 8742','hugig','gikgik','giykvi','Male','giig','Unmarried','igyvikyg','giyg','hgi','gig'),(' 3515','hugu','hlouih','houlho','Male','ohuulh','Unmarried','holuboui','ohuh','ihlon','ohol'),(' 4636','kbgyigf','giyvyi','ugbkkig','Male','gikbug','Unmarried','gukogui','iugvgui','guigi','giuik'),(' 2082','bgiyg','giyuji','nlhb','Male','bhuokhb','Married','nhob','houlh','goug','ougu'),(' 7713','abc','ff','Oct 2, 2025','Female','dd','Unmarried','cc','hvf','htrb','fh'),(' 8174','grtrt','ddfer','rf','Male','sdf','Married','feffrfewds','fdf','fef','gt'),(' 9270','ygigi','gbiygb','Oct 14, 2025','Male','','null','','','',''),(' 5114','nkiuhih','','','null','','null','','','',''),(' 5994','','','','null','','null','','','',''),(' 6362','','','','null','','null','','','',''),(' 6008','fdgd','','','null','','null','','','',''),(' 9788','er','','','null','','null','','','',''),(' 6993','q','','','null','','null','','','',''),(' 5616','er','','','null','','null','','','',''),(' 4959','we','qw','','null','','null','','','',''),(' 4585','jknlk','bjkn','','null','rt5','null','','','',''),(' 5675','as','wg','','null','rgrte','null','hgre','vre','fer','ger'),(' 1283','tyut','tuyt','hiuhuig','Male','guigi','null','huihk','giuhgi','igiug','giyygi'),(' 2842','rtt','utrfy','utfty','null','futfu','null','futf','futfutf','futfut','futfu'),(' 4940','ygyug','gyugyu','yufcu','Male','fiyvuy','null','yifvifv','fyujfv','fuyfvu','fuyv'),(' 7151','f4w','f gre','','Male','rml;','Unmarried','frml;re','rmg;','rmg;','grklmg;l5'),(' 5144','hjhw','fmklw4','','Male','kmf;','Married','mf4m','fm','nel','mf'),(' 4355','jknjk','kjnfkj','Oct 8, 2025','Male','nfie4l','Married','n43m','5klg','4kltnl','n34l'),(' 1822','jken','kjnf','Oct 2, 2025','Male','klnf','Unmarried','grt','gt','g5g','g5'),(' 4711','ygug','yugvuk','Oct 14, 2025','Male','yguuu','Married','gyu','giy','gyi','igyl'),(' 110','iygyi','gyigy','Oct 21, 2025','Male','ihgyk','Married','gyiiyi','gigig','giyiygigig','gigig'),(' 1419','jhf','rgnre','Oct 9, 2025','Male','tmek','Unmarried','gre','m,t 5','gnlk5','tnl5'),(' 7707','wr','gg','Oct 10, 2025','Male','gt','Married','bgngngn','bvn','hjh','hm'),(' 1384','jisd','cb jsd','Oct 2, 2025','Male','jnksd','Married','kjnd','lknokl','83','iusik'),(' 5411','hvfj','hjvjh','Oct 3, 2025','Male','hjvhj','Married','jkn','buihi','679v','jhvk'),(' 7731','688','hjbh','Oct 8, 2025','Male','jb','Married','jkjk','uui','jkjk','jkjk'),(' 1799','ijwe','kljwioew','Nov 7, 2025','Male','jlkwe;d','Married','ewjkjowe','wejknddkw','weknkwe','wjhdi'),(' 3551','jng','rm,g ,','Nov 6, 2025','Male','ghtr','Married','nfhhy','gn','hhgm','ujy'),(' 4227','dfff','vgrb','Nov 5, 2025','Male','dvv','Unmarried','fvtr','eff','12356','2245'),(' 415','nhjjk','vjj','Nov 11, 2025','Male','gvvhv','Married','hbkj','jbjk','bkj','nbjkn'),(' 3567','hvhj','vhjh','Nov 2, 2025','Male','nbjh','Married','bun','bjkn','hjbk','hbkj');
/*!40000 ALTER TABLE `signup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-23 16:34:42

CREATE DATABASE  IF NOT EXISTS `banksystem` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `banksystem`;
-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: banksystem
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bank`
--

DROP TABLE IF EXISTS `bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank` (
  `pin` varchar(10) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `amount` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank`
--

LOCK TABLES `bank` WRITE;
/*!40000 ALTER TABLE `bank` DISABLE KEYS */;
INSERT INTO `bank` VALUES ('1234','Sat Oct 25 11:46:05 IST 2025','Deposit','10000'),('1234','Sat Oct 25 11:46:18 IST 2025','Withdrawl','5000'),('334','Sat Oct 25 11:46:57 IST 2025','Deposit','5000'),('334','Sat Oct 25 11:47:09 IST 2025','Withdrawl','1000'),('334','Sat Oct 25 11:47:33 IST 2025','Withdrawl','2500'),('5891','Thu Oct 30 09:19:18 IST 2025','Deposit','10000000000000000000'),('5891','Thu Oct 30 09:20:36 IST 2025','Deposit','1000'),('1843','Thu Oct 30 09:24:23 IST 2025','Deposit','1234'),('1843','Thu Oct 30 09:24:38 IST 2025','Withdrawl','123'),('2906','Thu Oct 30 15:15:45 IST 2025','Deposit','4567'),('2906','Thu Oct 30 15:16:03 IST 2025','Withdrawl','1234'),('7939','Fri Oct 31 23:15:52 IST 2025','Deposit','1000'),('7939','Fri Oct 31 23:16:11 IST 2025','Withdrawl','500'),('7939','Fri Oct 31 23:28:42 IST 2025','Deposit','12000'),('7939','Fri Oct 31 23:29:12 IST 2025','Withdrawl','10000'),('7785','Mon Nov 03 09:55:51 IST 2025','Deposit','10000'),('7785','Mon Nov 03 09:56:06 IST 2025','Withdrawl','2000'),('2297','Sun Nov 16 13:35:12 IST 2025','Deposit','10000'),('2297','Sun Nov 16 13:35:27 IST 2025','Withdrawl','2000'),('2125','Wed Nov 19 15:18:23 IST 2025','Deposit','10000'),('2125','Wed Nov 19 15:18:36 IST 2025','Withdrawl','2999'),('4534','Sun Nov 23 16:14:24 IST 2025','Deposit','5789'),('4534','Sun Nov 23 16:14:40 IST 2025','withdrawl','2000');
/*!40000 ALTER TABLE `bank` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-23 16:34:43
